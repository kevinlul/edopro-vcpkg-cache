var searchData=
[
  ['evbuffer_5fcb',['evbuffer_cb',['../buffer__compat_8h.html#a6df4ae9e3d819c487ded545d2e1d41b0',1,'buffer_compat.h']]],
  ['evbuffer_5fcb_5ffunc',['evbuffer_cb_func',['../buffer_8h.html#a8f16422514b698553f34c0eba180f3fa',1,'buffer.h']]],
  ['evbuffer_5ffile_5fsegment_5fcleanup_5fcb',['evbuffer_file_segment_cleanup_cb',['../buffer_8h.html#aa0e56a17ff87cf097011902b80dd53bf',1,'buffer.h']]],
  ['evbuffer_5fref_5fcleanup_5fcb',['evbuffer_ref_cleanup_cb',['../buffer_8h.html#a66c442353fa5159e2acd808794fa92d6',1,'buffer.h']]],
  ['evdns_5fcallback_5ftype',['evdns_callback_type',['../dns_8h.html#a43018959c4be1a9b16e4143c5e3ff556',1,'dns.h']]],
  ['evdns_5fdebug_5flog_5ffn_5ftype',['evdns_debug_log_fn_type',['../dns_8h.html#a850904a1dbd8c8a087dc2be7617e21c8',1,'dns.h']]],
  ['evdns_5fgetaddrinfo_5fcb',['evdns_getaddrinfo_cb',['../dns_8h.html#a0d1464f191ef7678be0d4caf3644a8f4',1,'dns.h']]],
  ['evdns_5frequest_5fcallback_5ffn_5ftype',['evdns_request_callback_fn_type',['../dns_8h.html#a052802966f4c9d482279a05197dff005',1,'dns.h']]],
  ['event_5fbase_5fforeach_5fevent_5fcb',['event_base_foreach_event_cb',['../event_8h.html#a61f656b17425f17ed857b96d45fc6268',1,'event.h']]],
  ['event_5fcallback_5ffn',['event_callback_fn',['../event_8h.html#aed2307f3d9b38e07cc10c2607322d758',1,'event.h']]],
  ['event_5ffatal_5fcb',['event_fatal_cb',['../event_8h.html#abb799b636f0d3aab6ca17426d88473cf',1,'event.h']]],
  ['event_5ffinalize_5fcallback_5ffn',['event_finalize_callback_fn',['../event_8h.html#a6f62afb6e295ee487ad947e4eec18332',1,'event.h']]],
  ['event_5flog_5fcb',['event_log_cb',['../event_8h.html#a185f44c610d7ee21ecba720561b2e09c',1,'event.h']]]
];
