var searchData=
[
  ['libevent_5fglobal_5fshutdown',['libevent_global_shutdown',['../event_8h.html#aaed24b9ff1f5b137ea2e2cc6a2bf8d1f',1,'event.h']]]
];
