var searchData=
[
  ['bev_5fevent_5fconnected',['BEV_EVENT_CONNECTED',['../bufferevent_8h.html#affb7a7e5e21e1541ba6f43f950d92993',1,'bufferevent.h']]],
  ['bev_5fevent_5feof',['BEV_EVENT_EOF',['../bufferevent_8h.html#a4d7d8c93cf62e6f3d37c0cbac75aebcc',1,'bufferevent.h']]],
  ['bev_5fevent_5ferror',['BEV_EVENT_ERROR',['../bufferevent_8h.html#a5f112d7a064258bdabf8d5182a3bf5e4',1,'bufferevent.h']]],
  ['bev_5fevent_5freading',['BEV_EVENT_READING',['../bufferevent_8h.html#a504816ca8678e4f3d0bee2700fda524d',1,'bufferevent.h']]],
  ['bev_5fevent_5ftimeout',['BEV_EVENT_TIMEOUT',['../bufferevent_8h.html#aa537428e3ac2c8d2dbb4ec041f09347f',1,'bufferevent.h']]],
  ['bev_5fevent_5fwriting',['BEV_EVENT_WRITING',['../bufferevent_8h.html#a557afaa0ce75e6bbb71fdcd68c35d077',1,'bufferevent.h']]]
];
