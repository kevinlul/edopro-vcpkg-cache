var searchData=
[
  ['libevent_5fversion',['LIBEVENT_VERSION',['../event_8h.html#aad00c7d4ddbd6b590c15861a2e767182',1,'event.h']]],
  ['libevent_5fversion_5fnumber',['LIBEVENT_VERSION_NUMBER',['../event_8h.html#a8a9c8021651a2d8d7946083281279586',1,'event.h']]]
];
