var searchData=
[
  ['orig_5fsize',['orig_size',['../structevbuffer__cb__info.html#a18e973448576100923328e4de05ddef5',1,'evbuffer_cb_info']]]
];
