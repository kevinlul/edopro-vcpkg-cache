var searchData=
[
  ['bev_5ferror',['BEV_ERROR',['../bufferevent_8h.html#a19e499f7bfa831b802fd3575d141b4e1a4e51550811d3dad92400c27d69277032',1,'bufferevent.h']]],
  ['bev_5ffinished',['BEV_FINISHED',['../bufferevent_8h.html#ac35edc760057a2e48b4e8ba9ecf2ad25acb248a91854bbebd773061df7f4bbc94',1,'bufferevent.h']]],
  ['bev_5fflush',['BEV_FLUSH',['../bufferevent_8h.html#ac35edc760057a2e48b4e8ba9ecf2ad25a77e7f15a95815dcaaef27fdabb0e6164',1,'bufferevent.h']]],
  ['bev_5fneed_5fmore',['BEV_NEED_MORE',['../bufferevent_8h.html#a19e499f7bfa831b802fd3575d141b4e1a78c4f864aee50d333d74e3b46e12b8a4',1,'bufferevent.h']]],
  ['bev_5fnormal',['BEV_NORMAL',['../bufferevent_8h.html#ac35edc760057a2e48b4e8ba9ecf2ad25a81903ce04ca68ac1680dd0b7a28a7fce',1,'bufferevent.h']]],
  ['bev_5fok',['BEV_OK',['../bufferevent_8h.html#a19e499f7bfa831b802fd3575d141b4e1a794bf8211eaafdbeb382991dc5874e4d',1,'bufferevent.h']]],
  ['bev_5fopt_5fclose_5fon_5ffree',['BEV_OPT_CLOSE_ON_FREE',['../bufferevent_8h.html#aa4919449c62c6483e2d135509190dc65a5dc89d74ef445da33295d00c8f6adc90',1,'bufferevent.h']]],
  ['bev_5fopt_5fdefer_5fcallbacks',['BEV_OPT_DEFER_CALLBACKS',['../bufferevent_8h.html#aa4919449c62c6483e2d135509190dc65a2fbeb24d0156aa2492c23aaace73f1d3',1,'bufferevent.h']]],
  ['bev_5fopt_5fthreadsafe',['BEV_OPT_THREADSAFE',['../bufferevent_8h.html#aa4919449c62c6483e2d135509190dc65adfb637881b739eff1441ad848a5e3a2d',1,'bufferevent.h']]],
  ['bev_5fopt_5funlock_5fcallbacks',['BEV_OPT_UNLOCK_CALLBACKS',['../bufferevent_8h.html#aa4919449c62c6483e2d135509190dc65acb8ca6f6422fb8f9a748521cf8c4caf5',1,'bufferevent.h']]],
  ['bev_5ftrig_5fdefer_5fcallbacks',['BEV_TRIG_DEFER_CALLBACKS',['../bufferevent_8h.html#a7837b6947fc855924466e2347a6faa8faef788894ba060effdd88553e59eb1330',1,'bufferevent.h']]],
  ['bev_5ftrig_5fignore_5fwatermarks',['BEV_TRIG_IGNORE_WATERMARKS',['../bufferevent_8h.html#a7837b6947fc855924466e2347a6faa8fa02d5d43f86f75f0f1569ca2b16025bfc',1,'bufferevent.h']]]
];
