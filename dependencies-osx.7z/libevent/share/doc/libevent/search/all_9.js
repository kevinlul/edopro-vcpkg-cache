var searchData=
[
  ['n_5fadded',['n_added',['../structevbuffer__cb__info.html#a8191bbc06e291543359428daace6bae6',1,'evbuffer_cb_info']]],
  ['n_5fdeleted',['n_deleted',['../structevbuffer__cb__info.html#a7d1a674e020d2eee72538b0221dc32a4',1,'evbuffer_cb_info']]]
];
