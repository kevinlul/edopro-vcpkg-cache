var searchData=
[
  ['iov_5fbase',['iov_base',['../structevbuffer__iovec.html#a1ce384c93f7554ab94f5dccdab8b4e13',1,'evbuffer_iovec']]],
  ['iov_5flen',['iov_len',['../structevbuffer__iovec.html#a0b1981aa931c720e63238022d74c0ac1',1,'evbuffer_iovec']]]
];
