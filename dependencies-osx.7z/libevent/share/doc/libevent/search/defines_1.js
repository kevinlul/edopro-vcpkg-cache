var searchData=
[
  ['dns_5ferr_5fcancel',['DNS_ERR_CANCEL',['../dns_8h.html#aa213c5179d5439b1ceb6b356cfa6670a',1,'dns.h']]],
  ['dns_5ferr_5fformat',['DNS_ERR_FORMAT',['../dns_8h.html#af83b8dba06d732f95c5134a26189bf07',1,'dns.h']]],
  ['dns_5ferr_5fnodata',['DNS_ERR_NODATA',['../dns_8h.html#a339623396788ff9271b5cc345b83a2e8',1,'dns.h']]],
  ['dns_5ferr_5fnone',['DNS_ERR_NONE',['../dns_8h.html#a9ab3095d5fc6b9b476753f1dc43ca062',1,'dns.h']]],
  ['dns_5ferr_5fnotexist',['DNS_ERR_NOTEXIST',['../dns_8h.html#a69a1417da1abb3ec925bac4bdc9dda00',1,'dns.h']]],
  ['dns_5ferr_5fnotimpl',['DNS_ERR_NOTIMPL',['../dns_8h.html#ad4c885f89aab5bba9636bcab0b2bb46f',1,'dns.h']]],
  ['dns_5ferr_5frefused',['DNS_ERR_REFUSED',['../dns_8h.html#ac2612a0b4f473b2e0d8353968cf958c8',1,'dns.h']]],
  ['dns_5ferr_5fserverfailed',['DNS_ERR_SERVERFAILED',['../dns_8h.html#a288664d29454d839d3337c9f1a16287b',1,'dns.h']]],
  ['dns_5ferr_5fshutdown',['DNS_ERR_SHUTDOWN',['../dns_8h.html#ad64cc74ddb454b815d42e23b4d24bf16',1,'dns.h']]],
  ['dns_5ferr_5ftimeout',['DNS_ERR_TIMEOUT',['../dns_8h.html#acb501430c13d4432314859d36b21c59c',1,'dns.h']]],
  ['dns_5ferr_5ftruncated',['DNS_ERR_TRUNCATED',['../dns_8h.html#ab133c94928a9ebe3d37ad5a5d3722fb8',1,'dns.h']]],
  ['dns_5ferr_5funknown',['DNS_ERR_UNKNOWN',['../dns_8h.html#a09a9900444d399cb6d516e40a1629f79',1,'dns.h']]],
  ['dns_5foptions_5fall',['DNS_OPTIONS_ALL',['../dns_8h.html#a417f74bbbbd887a84d911ed9dc7ce3ae',1,'dns.h']]]
];
